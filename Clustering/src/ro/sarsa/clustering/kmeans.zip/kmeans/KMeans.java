package ro.sarsa.clustering.kmeans;

import java.util.List;

import ro.sarsa.clustering.IDistance;
import ro.sarsa.clustering.Partition;

public class KMeans<T extends ObjectWithFeature> {
	private IDistance<ObjectWithFeature> dist;

	public KMeans() {
		this(new EuclidianDistanceFeature());
	}

	public KMeans(IDistance<ObjectWithFeature> dist) {
		this.dist = dist;
	}

	/**
	 * Calculeaza centroidul
	 * 
	 * @param objects
	 * @return
	 */
	private Centroid computeCentroizi(List<T> objects) {
		// TODO calculez centroidul
		double[] centroidFeatureValues = new double[objects.get(0)
				.getFeatures().length];
		// calculam mediiile
		for (T ob : objects) {
           
		}
		return new Centroid(centroidFeatureValues);
	}

	public Partition<T> clustering(List<T> objects) {
		Centroid c = computeCentroizi(objects);
		dist.distance(c, objects.get(0));
		return null;
	}

	public static void main(String[] args) {
		KMeans<ObjectWithFeature> kmens = new KMeans<ObjectWithFeature>();
	}
}
