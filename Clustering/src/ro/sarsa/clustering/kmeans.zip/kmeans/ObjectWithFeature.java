package ro.sarsa.clustering.kmeans;

public interface ObjectWithFeature {
	double[] getFeatures();
}
