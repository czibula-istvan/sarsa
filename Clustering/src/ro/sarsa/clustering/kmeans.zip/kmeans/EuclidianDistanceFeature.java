package ro.sarsa.clustering.kmeans;

import ro.sarsa.clustering.IDistance;
import ro.sarsa.clustering.distances.EuclideanDistance;

public class EuclidianDistanceFeature implements IDistance<ObjectWithFeature> {
	private EuclideanDistance dist = new EuclideanDistance();

	@Override
	public double distance(ObjectWithFeature a, ObjectWithFeature b) {
		return dist.distance(a.getFeatures(), b.getFeatures());
	}

	@Override
	public double getIninity() {
		return dist.getIninity();
	}

}
